const apiPath = {
    data:function () {
        return {
            loginUrl: "/login",                                         //登录接口
            selectAllUserUrl: "/selectAllUser",                         //查询所有管理员接口
            addUserUrl: "/insertUser",                                  //新增管理员接口
            deleteUserUrl: "/deleteUser",                               //删除管理员接口
            editUserUrl: '/updateUser',                                 //更新管理员信息接口
            selectLoginTimeoutUrl: 'selectLoginTimeout',                //获取登录超时时间接口
            updateLoginTimeoutUrl: 'updateLoginTimeout',                //更新登录超时接口
            getIPUrl: '/ip/getIP',                                      //获取ip信息接口
            geditIPUrl: '/ip/geditIP',                                  //ip修改接口
            insertRTSPUrl: '/camera/add/rtsp',                          //添加rtsp流
            selectAllRTSPUrl: '/camera/selectAll/rtsp',                 //查询所有rtsp流
            // stopRTSPUrl: '/camera/stop/rtsp',                           //弃用
            updateRTSPConfigUrl: '/camera/update/rtsp/config',          //更新设置
            algorithmModeURL: '/camera/update/algorithmMode',           //更新算法模式
            updateParkingPointUrl: "/car/updateParkingPoint",           //更新停车点信息
            getCarBoundingBoxUrl: "/car/getCarBoundingBox",             //获取停车识别框
            getCarBoxLiveUrl: "/car/getCarBoxLive",                     //获取停车识别实时画面
            getFaceBoxLiveUrl: "/face/getFaceBoxLive",                  //获取人脸识别实时画面
            checkpointsUrl: "/camera/detect/checkpoints",               //弃用
            getFaceRecordUrl: "/face/getFaceRecord",                    //获取人脸识别记录
            getParkingPointUrl: "/car/getParkingPoint",                 //获取停车记录
            insertFaceUrl: "/face/insertFace",                          //人脸库录入
            runCommandUrl: '/net/runCommand',                           //网络诊断
            updateRtspEnableUrl: '/camera/update/rtspEnable',           //更新摄像头启用状态
            getFaceRecordByPageUrl: '/face/getFaceRecordByPage',        //获取人脸识别记录分页
            getPeopleInfoByPageUrl: '/face/getPeopleInfoByPage'         //获取人脸库人脸信息


            
            
        }
    },
    methods:{

    }
};
export default apiPath;