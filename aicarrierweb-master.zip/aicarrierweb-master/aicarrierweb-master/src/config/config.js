const localhost = window.location.host.split(':')[0]; // 生产环境中使用
module.exports = {
    title: "视频盒子",
    microServer: false, // 默认后端不是微服务
    // 单点配置
    cas: {
        enable: true, // 是否启用单点
        // 配置本机的ip地址，如果启用nginx时需要配置nginx的地址
        servicePrefix: "http://192.168.137.100:80",
        // servicePrefix: "http://192.168.200.8:7001",
        // 单点登陆的服务端地址
        serverPath: "http://localhost:8080",
        paths: {
            login: "/login", // 配置前端的登录路由
            logout: "/logout"
        }
    },
    // 后端请求配置
    axios: {
        // 配置后端的地址，如果启用nginx时需要配置nginx的地址
        // baseURL: "http://" + localhost + ":5000/v1", //后端请求接口ip:port
        baseURL: "http://192.168.137.100:5000/v1", //后端请求接口ip:port
        // wsurl: "ws://192.168.137.100:4567",
        // wsurl: "ws://192.168.137.100:4001",
        httpUrl: "http://192.168.137.100:5050/", // 图片地址
        wsurl: "ws://192.168.137.100:4567",
        // httpUrl: "http://" + localhost + ":5050/", // 图片地址
        // wsurl: "ws://" + localhost + ":4567",
        timeout: 1000 * 60,
        withCredentials: true,
        rtspURL: "rtsp://192.168.137.102:8557"
    },
    // 水印配置
    watermark: {
        enable: false,
        width: 400,
        height: 300,
        x: 0,
        y: 80,
        font: "SimSun Bold",
        fontSize: 20,
        color: "#000",
        alpha: 0.22,
        angle: -20,
        mode: "canvas"
    },
    // 不进行token校验的路由
    whiteList: ["/login", "/login/admin", "/logout"]
};
