import Vue from 'vue'
import App from './App.vue'
import ViewUI from 'view-design'
import router from './config/router'
import ElementUI from 'element-ui'
import 'view-design/dist/styles/iview.css';
import curl from '@/config/axios';
import BootstrapVue from "bootstrap-vue";
import 'bootstrap/dist/css/bootstrap.min.css';
import VEasy from "v-easy-components";
import 'v-easy-components/lib/theme-chalk/index.css';
import store from './config/store'
import $ from "jquery"

Vue.use(ViewUI);
Vue.use(ElementUI);
Vue.use(VEasy);
Vue.use(router);
Vue.use(BootstrapVue);
Vue.use($);
Vue.config.productionTip = false;
if (! Array.prototype.find) {
    Array.prototype.find = function(callback) {
        return callback && (this.filter(callback) || [])[0];
    };
}
if (! String.prototype.replaceAll) {
    String.prototype.replaceAll = function(s1, s2){
        return this.replace(new RegExp(s1, "gm"), s2);
    }
}
router.beforeEach((to, from, next) => {
    if (to.meta.title) {
        document.title = to.meta.title
    }
    if (to.path === '/login') {
        return next();
    } else {
        let token = window.sessionStorage.getItem("token");
        if (!token) {
            return next('/login');
        }
        return next();
    }
});
new Vue({
    curl,
    store,
    router,
    render: h => h(App),
}).$mount('#app');
