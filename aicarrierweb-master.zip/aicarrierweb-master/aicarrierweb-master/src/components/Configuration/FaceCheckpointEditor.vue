<template>
  <b-card fluid>
    <template v-slot:header>
      识别结果
      <!--            <b-button class="float-right" size="sm" variant="outline-secondary" v-b-modal.live>实时画面</b-button>-->
      <b-modal id="live" title="实时画面" size="lg" ok-only ok-title="返回">
        <b-img :src="host + '/camera/live'" fluid-grow />
      </b-modal>
    </template>
    <!-- 基于mjpeg流的识别结果图像 -->
<!--    <img-->
<!--      :src="host + getFaceBoxLiveUrl + '?url=' + url"-->
<!--      id="detectSource"-->
<!--      crossorigin="Anonymous"-->
<!--      :width="DWidth"-->
<!--      :height="DHeight"-->
<!--    />-->
    <object type='application/x-vlc-plugin' classid='clsid:9BE31822-FDAD-461B-AD51-BE1D1C159921'  id='vlc' style="width: 100%;height: 100%" events='True' pluginspage="http://www.videolan.org" codebase="http://download.videolan.org/pub/videolan/vlc/last/win32/axvlc.cab">
      <param name='mrl' :value='rtspUrl' />
      <param name='volume' value='50' />
      <param name='autoplay' value='true' />
      <param name='loop' value='false' />
      <param name='fullscreen' value='true' />
    </object>
  </b-card>
</template>

<script>
import axios from "axios";
import { v4 as uuid } from "uuid";
import PubSub from "pubsub-js";
import config from "@/config/config";
import http from "@/config/http";

class ParkingSpace {
  constructor(x, y, id, name, ctx) {
    this.x = x;
    this.y = y;
    this.id = id;
    this.ctx = ctx;
    this.name = name;
    this.radius = 5;
    this.available = true;
    this.highlight = false;
    this.availableCounter = 0;
  }

  isHover(mouseX, mouseY) {
    // 水平距离或垂直距离大于半径，则一定不可能悬停
    if (
      Math.abs(this.x - mouseX) > this.radius ||
      Math.abs(this.y - mouseY) > this.radius
    ) {
      return false;
    }
    let distance = Math.sqrt(
      (this.x - mouseX) * (this.x - mouseX) +
        (this.y - mouseY) * (this.y - mouseY)
    );
    if (distance > this.radius) {
      return false;
    }
    return true;
  }

  refreshAvailability(detections) {
    let available = true;
    let stateChanged = false;
    for (let e of detections) {
      let left = e[0];
      let top = e[1];
      let right = left + e[2];
      let bottom = top + e[3];
      if (this.y > top && this.y < bottom && this.x > left && this.x < right) {
        available = false;
        break;
      }
    }
    //模型容易把有车识别成没车，但不容易把没车识别成有车，所以连续识别三次没车才改变状态
    if (available) {
      this.availableCounter++;
      if (this.availableCounter == 3) {
        this.available = true;
        this.availableCounter = 0;
        stateChanged = true;
      }
    } else {
      if (this.available) stateChanged = true;
      this.available = false;
      this.availableCounter = 0;
    }
    return stateChanged;
  }

  refreshExterior(mouseX, mouseY) {
    this.ctx.beginPath();
    let isHover = this.isHover(mouseX, mouseY);
    let resizeFactor = this.highlight || isHover ? 1.5 : 1;
    this.ctx.arc(
      this.x,
      this.y,
      this.radius * resizeFactor,
      0,
      2 * Math.PI,
      false
    );
    this.ctx.fillStyle = (() => {
      if (this.highlight) return "#ffa500";
      if (this.available) return "#00ff00";
      return "#ff0000";
    })();
    this.ctx.fill();
    if (isHover) {
      this.ctx.lineWidth = 2;
      this.ctx.strokeStyle = this.available ? "#003300" : "#330000";
      this.ctx.stroke();
    }
  }
}

class ParkingSpaceStorage {
  constructor(ctx, host) {
    this.ctx = ctx;
    this.host = host;
    this.storage = new Map();
  }

  load(data) {
    for (let id in data) {
      this.create(data[id].x, data[id].y, false, id, data[id].name);
    }
  }

  create(x, y, exportNeeded, id = null, name = null) {
    let newID = id == null ? uuid() : id;
    let newName = name == null ? newID.substring(0, 5) : name;
    this.storage.set(
      newID,
      new ParkingSpace(Math.round(x), Math.round(y), newID, newName, this.ctx)
    );
    PubSub.publish("create", {
      x: Math.round(x),
      y: Math.round(y),
      id: newID,
      name: newName,
    });
    if (exportNeeded) this.export();
    return newID;
  }

  remove(element) {
    this.storage.delete(element.id);
    PubSub.publish("remove", element.id);
    this.export();
  }

  forEach(callback) {
    this.storage.forEach(callback);
  }

  refreshExterior(mouseX, mouseY) {
    this.forEach((ps) => {
      ps.refreshExterior(mouseX, mouseY);
    });
  }

  refreshAvailability(detections) {
    this.forEach((ps) => {
      let stateChanged = ps.refreshAvailability(detections);
      if (stateChanged) {
        PubSub.publish("change", { id: ps.id, available: ps.available });
      }
    });
  }

  rename(id, name) {
    let element = this.storage.get(id);
    element.name = name;
    this.storage.set(id, element);
    this.export();
  }

  highlight(id) {
    this.forEach((ps) => {
      if (ps.id == id) {
        ps.highlight = true;
      } else {
        ps.highlight = false;
      }
    });
  }

  isDuplicate(name) {
    let duplicate = false;
    this.forEach((ps) => {
      if (ps.name == name) duplicate = true;
    });
    return duplicate;
  }

  export() {
    let tempStorage = {};
    this.forEach((ps) => {
      tempStorage[ps.id] = { x: ps.x, y: ps.y, name: ps.name };
    });
    axios
      .post(this.host + this.checkpointsUrl, tempStorage)
      .then((resp) => {
        if (resp.code !== 200) {
          console.error("cannot post point data");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }
}


export default {
  name: "ckeckpoint-editor",
  mixins: [http],
  data: function () {
    return {
      //识别结果画布及其上下文
      detectCanvas: null,
      detectCtx: null,
      //车位（检查点）列表
      parkingSpaceStorage: null,
      //detection = [[x, y, w, h], [x, y, w, h], ...]
      detections: null,
      //鼠标位置
      mouseX: 0,
      mouseY: 0,
      //是否在编辑状态
      editable: false,
      //编辑状态相关
      editMode: "immediate",
      immediate: {
        ID: "",
        name: "",
        state: null,
      },
      continuals: {
        next: "001",
        state: null,
      },
      //是否还在初始化
      preparing: true,
      host: config.axios.baseURL,
      url: config.axios.rtspURL,
      DWidth: "100%",
      rtspUrl: ""
    };
  },
  methods: {
    rename: function () {
      if (this.parkingSpaceStorage.isDuplicate(this.immediate.name)) {
        this.immediate.state = false;
        return;
      }
      this.immediate.state = null;
      PubSub.publish("rename", {
        id: this.immediate.ID,
        name: this.immediate.name,
      });
    },
    continualsNext: function () {
      let digit = this.continuals.next.length;
      let newNext = `${Number.parseInt(this.continuals.next) + 1}`;
      while (newNext.length < digit) newNext = `0${newNext}`;
      this.continuals.next = newNext;
    },
  },
  created() {
    console.log(config.axios.rtspURL)
    this.rtspUrl = config.axios.rtspURL
    //创建对识别结果画布及其上下文的引用
    // this.detectCanvas = document.getElementById("detectCanvas");
    // this.detectCanvas.width = 720;
    // this.detectCanvas.height = 480;
    // this.detectCtx = document.getElementById("detectCanvas").getContext("2d");
    //初始化检查点储存
    this.parkingSpaceStorage = new ParkingSpaceStorage(
      this.detectCtx,
      this.host
    );
    //获取服务器端缓存的检查点信息
    // this.$curl.get(this.checkpointsUrl).then((res) => {
    //   if (res.code === 200) {
    //     this.parkingSpaceStorage.load(res.data);
    //   } else {
    //     this.$Message.warning(JSON.stringify(res));
    //   }
    // });
    // //获取识别框
    //  axios
    //     .get(`${this.host}/camera/detect/box`)
    //     .then((resp) => {
    //         if (resp.code == 200) {
    //             this.detections = resp.data;
    //         } else {
    //             this.detections = [];
    //             console.error("cannot fetch detections");
    //         }
    //     })
    //     .catch((err) => {
    //         console.error(`${err}`);
    //     });

    //当图像源宽度不是0（即已加载好）时取消"准备中"遮罩
    let prepareChecker = setInterval(() => {
      if (!document.getElementById("detectSource")){
        return ;
      }
      if (document.getElementById("detectSource").width != 0) {
        clearInterval(prepareChecker);
        this.preparing = false;
      }
    }, 50);

    //每50毫秒刷新一次画布
    let lastRefreshTimestamp = 0;
    let refreshCanvas = (time) => {
      if (time - lastRefreshTimestamp > 50) {
        lastRefreshTimestamp = time;
        let source = document.getElementById("detectSource");
        try {
          this.detectCtx.drawImage(source, 0, 0);
        } catch (error) {
          /*ignore warning*/
        }
        this.parkingSpaceStorage.refreshExterior(this.mouseX, this.mouseY);
      }
      requestAnimationFrame(refreshCanvas);
    };
    requestAnimationFrame(refreshCanvas);

    //每4秒获取一次识别框并刷新占用情况
    let lastFetchTimestamp = 0;
    // let fetchDetection = async (time) => {
    //     if (time - lastFetchTimestamp > 4000) {
    //         lastFetchTimestamp = time;
    //         await axios
    //             .get(`${this.host}/camera/detect/box`)
    //             .then((resp) => {
    //                 if (resp.code == 200) {
    //                     this.detections = resp.data;
    //                 } else {
    //                     this.detections = [];
    //                     console.error("cannot fetch detections");
    //                 }
    //             })
    //             .catch((err) => {
    //                 console.error(err);
    //             });
    //         this.parkingSpaceStorage.refreshAvailability(this.detections);
    //     }
    //     requestAnimationFrame(fetchDetection);
    // }
    // requestAnimationFrame(fetchDetection);


    /**
     * Provides requestAnimationFrame in a cross browser way.
     * http://paulirish.com/2011/requestanimationframe-for-smart-animating/
     */
    if (!window.requestAnimationFrame) {
      window.requestAnimationFrame = (function () {
        return (
          window.webkitRequestAnimationFrame ||
          window.mozRequestAnimationFrame ||
          window.oRequestAnimationFrame ||
          window.msRequestAnimationFrame ||
          function (callback) {
            window.setTimeout(callback, 1000 / 60);
          }
        );
      })();
    }
  },
  mounted() {
    $(".card").height("75vh")
      // 设置窗口变化改变视频大小
    var _this = this;
    window.onresize = () => {
      return (() => {
        if (!document.getElementById("detectSource")) {
          return ;
        }
        var w = document.getElementById("detectSource").width;
        var h = document.getElementById("detectSource").height;
        var d = w / 720;
        _this.DHeight = 480 * d;
      })();
    };
  },
  watch: {
    editable(newVal) {
      if (newVal) PubSub.publish("edit-start");
      else PubSub.publish("edit-end");
    },
  },
};
</script>

<style scoped>
  object {
    width: 100% !important;
    height: 100% !important;
    box-sizing: border-box !important;
  }
#detectCanvas {
  width: 100%;
}
</style>
