<template>
    <Layout>
        <Sider style="background-color: white; border-right: 1px solid #dcdee2">
            <Table highlight-row :columns="tableHead" :data="deviceData" @on-current-change="liveChange" border>
                <template slot-scope="{ row }" slot="name">
                    <strong style="cursor:pointer">{{ row.name }}</strong>
                </template>
            </Table>
        </Sider>
        <Layout style="display: flex">
            <Header class="liveTitle" style="background-color: white">
                <font style="font-size: large">实时画面</font>
            </Header>
            <div id="viewBox">
                <object @on-cancel="stopRTSP" type='application/x-vlc-plugin' classid='clsid:9BE31822-FDAD-461B-AD51-BE1D1C159921'  id='vlc' style="" events='True' pluginspage="http://www.videolan.org" codebase="http://download.videolan.org/pub/videolan/vlc/last/win32/axvlc.cab">
                    <param name='mrl' :value='rtspUrl' />
                    <param name='volume' value='50' />
                    <param name='autoplay' value='true' />
                    <param name='loop' value='false' />
                    <param name='fullscreen' value='true' />
                </object>

            </div>
        </Layout>
        <Sider
                style="
        display: none;
        background-color: #ffffff;
        border-left: 1px solid #dcdee2;
      "
        >侧边栏
        </Sider
        >
    </Layout>
</template>

<script>
    import http from "@/config/http";
    import {axios} from "@/config/config";
    import $ from "jquery";

    export default {
        name: "live",
        data() {
            return {
                split1: 0.5,
                tableHead: [
                    {
                        title: "设备",
                        key: "name",
                        sortable: true,
                        align: "center",
                    },
                ],
                deviceData: [],
                liveUrl: "",
                rtspUrl: "",
                LPWidth: "90%",
                LPHeight: false,
            };
        },
        methods: {
            liveChange(currentRow, oldCurrentRow) {
                let url = this.stopRTSPUrl;
                let data = {url: this.rtspUrl};
                this.$curl.post(url, data).then(
                    (res) => {
                        if (res.code === 200) {
                            console.log("success");
                        } else {
                            console.log(res.msg);
                        }
                    },
                    (err) => {
                        console.log("fail");
                    }
                );
                this.liveUrl = axios.baseURL + "/camera/live?url=";
                this.liveUrl += currentRow.url;
                this.rtspUrl = currentRow.url;

                this.playrtsp(this.rtspUrl)

            },
            playrtsp(rtspurl) {
                // alert(rtspurl)
                // var viewBoxHtml = $("#viewBox").html()
                // $("#viewBox").html(viewBoxHtml)

                var vlc = document.getElementById("vlc")
                let id = vlc.playlist.add(rtspurl);
                // console.log(vlc.playlist.add("rtsp://192.168.137.102:8557"))
                vlc.playlist.playItem(id); // 列表添加播放内容
                vlc.playlist.play() // 开始播放
            },
            stopRTSP() {
                let vlc = document.getElementById("vlc");
                vlc.playlist.stop();
                vlc.playlist.clear();
                console.log("停止和清楚视频缓存")
            },
        },
        created() {

            let url = this.selectAllRTSPUrl;
            // alert(url)
            this.$curl.post(url).then(
                (res) => {
                    if (res.code === 200) {
                        this.deviceData = res.data;
                        if (res.data.length !== 0) {
                            this.liveUrl = axios.baseURL + "/camera/live?url=";
                            this.liveUrl += res.data[0].url;
                            this.rtspUrl = res.data[0].url;
                            this.playrtsp(this.rtspUrl)
                        }
                    } else {
                        this.$Message.warning(res.msg);
                    }
                },
                (err) => {
                    this.$Message(JSON.stringify(err));
                }
            );
        },
        mounted() {
            // 监视窗口变化
            let _this = this;
            window.onresize = () => {
                return (() => {
                    if (!document.getElementById("livePicture"))
                        return ;
                    let w = document.getElementById("livePicture").width;
                    let h = document.getElementById("livePicture").height;
                    let vh = document.getElementById("viewBox").offsetHeight;
                    let vw = document.getElementById("viewBox").offsetWidth;
                    // console.log("h>v -> w:" + w, "h:" + h, "vw:" + vw, "vh:" + vh);

                    // _this.LPWidth = vw

                    let d = 480 / 720;
                    console.log("400 / d:", 600 / d);
                    if (w < vw - 70) {
                        _this.LPHeight = vh - 150;
                        _this.LPWidth = _this.LPHeight / d;
                    } else if (h < vh - 70) {
                        _this.LPWidth = vw - 60;
                        _this.LPHeight = _this.LPWidth * d;
                    }

                })();
            };
        },
        destroyed() {
            let url = this.stopRTSPUrl;
            let data = {url: this.rtspUrl};
            this.$curl.post(url, data).then(
                (res) => {
                    if (res.code === 200) {
                        console.log("success");
                    } else {
                        console.log(res.msg);
                    }
                },
                (err) => {
                    console.log("fail");
                }
            );
            this.stopRTSP();
        },
        mixins: [http],
    };
</script>

<style scoped lang="less">
    object {
        width: 100% !important;
        height: 100% !important;
        box-sizing: border-box !important;
    }
    .pad-center {
        margin-top: 20px;
        width: 55%;
        margin-left: 20px;
        margin-right: 20px;
        height: 100%;
        display: inline-block;
        background-color: #eb2f96;
    }

    .pad-right {
        width: 20%;
        height: 100%;
        display: inline-block;
        background-color: #67c23a;
    }

    .livePicture {
        // margin-top: 20px;
        border: 1px solid rgba(0, 0, 0, 0.5);
    }

    #viewBox {
        height: 100vh;
        padding: 30px;
        padding-bottom: 100px;
        border-radius: 10px;
        // background: red;
        position: relative;
    }

    #viewBox img {
        border-radius: 5px;
        position: absolute;
        left: 50%;
        transform: translate(-50%, 0);
    }
</style>