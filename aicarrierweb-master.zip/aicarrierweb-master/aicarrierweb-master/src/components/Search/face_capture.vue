<template>
    <div class="rightNav">
        <!--        <ul class="tab-nav">-->
        <!--            <h3 style="padding:5px 0 5px 10px;border-bottom:1px solid #c2c2c2;">设备管理树</h3>-->
        <!--        </ul>-->
        <div class="test3" style="height: 100%">
            <div style="border-bottom:1px solid #c2c2c2;">
                <h3 style="padding:5px 0 5px 10px;">人脸抓拍</h3>
            </div>
            <div style="margin:10px 0px 0px 10px;width: 98.5%;height: 100%">
                <div style="width:100%;height: 85%">
                    <DatePicker @on-change="dateChange" type="datetimerange" format="yyyy-MM-dd HH:mm" placeholder="选择时间区段" style="float:left;width: 300px"></DatePicker>
                    <Select @on-change="deviceChange" placeholder="全选" v-model="deviceChoose"
                            style="width:100px;padding-left: 10px">
                        <Option v-for="item in deviceLabelList" :value="item.value" :key="item.value">{{ item.label }}
                        </Option>
                    </Select>
                    <Button type="primary" style="margin-left: 25px" @click="selectFaceRecordByPage(deviceUrl)">查询</Button>
                    <br>
                    <br>
                    <Table :loading="loading" :columns="deviceTableLabelList" :data="deviceList" @on-cell-click="onCellClick" width="90%" height="650">
                        <template slot-scope="{ row }" slot="imgSlot">
                            <img :src="row.filePath" width="70px" height="70px"/>
                        </template>
                    </Table>
                </div>
                <div style="width: 98.5%;">
                    <Page :current="pageNum" :page-size="pageSize" :total="deviceTotal"
                          @on-page-size-change="onPageSizeChange" @on-change="onPageNumChange" show-sizer
                          style="float: right;margin-right: 10px;font-size: 12px"/>
                </div>

                <Modal v-model="showBigPic" footer-hide width="80%" style="margin-top: -150px;">
                    <img :src="bigPicUrl" width="100%" style="object-fit: cover">
                </Modal>
            </div>
        </div>
    </div>
</template>

<script>
    import http from '@/config/http';
    import config from '@/config/config';

    export default {
        name: "face_capture",
        data() {
            return {
                deviceLabelList: [],
                deviceList: [],
                deviceTableLabelList: [
                    {
                        title: 'id',
                        key: 'id'
                    },
                    {
                        title: '图片',
                        key: 'filePath',
                        slot: 'imgSlot'
                    },
                    {
                        title: '用户编号',
                        key: 'userId'
                    },
                    {
                        title: '用户姓名',
                        key: 'name'
                    },
                    {
                        title: '抓拍日期',
                        key: 'timestamp'
                    }

                ],
                deviceChoose: '全选',
                deviceUrl: '全选',
                deviceTotal: 0,
                pageSize: 10,
                pageNum: 1,
                httpurl: config.axios.httpUrl,
                loading: true,
                bigPicUrl: '',
                showBigPic: false,
                sTime: 0,
                eTime: 0
            }
        },
        methods: {
            selectFaceRecordByPage: function (url = null) {
                this.loading = true;
                let data = {
                    pageNum: this.pageNum,
                    pageSize: this.pageSize,
                    url: url == "全选" ? null : url,
                    sTime: this.sTime,
                    eTime: this.eTime
                };
                this.$curl.post(this.getFaceRecordByPageUrl, data).then(res => {
                    if (res.code === 200) {
                        this.deviceTotal = res.data.total;
                        for (let i in res.data.rows) {
                            res.data.rows[i].filePath = this.httpurl + res.data.rows[i].filePath;
                            res.data.rows[i].timestamp = this.format(
                                new Date(res.data.rows[i].timestamp <= 9999999999 ? (res.data.rows[i].timestamp * 1000) : res.data.rows[i].timestamp), "yyyy-MM-dd hh:mm:ss"
                            );
                        }
                        this.deviceList = res.data.rows;
                        this.loading = false;
                    } else {
                        this.$Message.warning(res.msg);
                    }
                }, err => {
                    this.$Message.error(err);
                })

            },
            deviceChange: function (data) {
                if (data !== 'undefined' && data !== '') {
                    this.deviceUrl = data;
                }
            },
            dateChange: function(date, type) {
                let sTimeDate = new Date(date[0]);
                let eTimeDate = new Date(date[1]);
                this.sTime = sTimeDate.getTime();
                this.eTime = eTimeDate.getTime();
            },
            onPageSizeChange: function (data) {
                this.pageSize = data;
                this.selectFaceRecordByPage(this.deviceUrl);
            },
            onPageNumChange: function (data) {
                this.pageNum = data;
                this.selectFaceRecordByPage(this.deviceUrl);
            },
            onCellClick: function (row, column, data, event){
                if (column.key === 'filePath') {
                    this.bigPicUrl = data;
                    this.showBigPic = true;
                }
            },
            format: function (date, fmt) {
                if (/(y+)/.test(fmt)) {
                    fmt = fmt.replace(
                        RegExp.$1,
                        (date.getFullYear() + "").substr(4 - RegExp.$1.length)
                    );
                }
                let o = {
                    "M+": date.getMonth() + 1,
                    "d+": date.getDate(),
                    "h+": date.getHours(),
                    "m+": date.getMinutes(),
                    "s+": date.getSeconds(),
                };
                for (let k in o) {
                    if (new RegExp(`(${k})`).test(fmt)) {
                        let str = o[k] + "";
                        fmt = fmt.replace(
                            RegExp.$1,
                            RegExp.$1.length === 1 ? str : padLeftZero(str)
                        );
                    }
                }

                function padLeftZero(str) {
                    return ("00" + str).substr(str.length);
                }

                return fmt;
            },
        },
        created() {
            let url = this.selectAllRTSPUrl;
            this.$curl.post(url).then(res => {
                if (res.code === 200) {
                    this.deviceLabelList.push({'label': '全选', 'value': '全选'});
                    for (let i in res.data)
                        this.deviceLabelList.push({'label': res.data[i].name, 'value': res.data[i].url});
                    this.selectFaceRecordByPage();
                } else {
                    this.$Message.warning(res.msg);
                }
            }, err => {
                this.$Message.error(err);
            });

        },
        mixins: [http]
    }
</script>
<style>
    .test3 {

        width: 100%;
        display: flex;
        flex-direction: column;
    }
</style>
