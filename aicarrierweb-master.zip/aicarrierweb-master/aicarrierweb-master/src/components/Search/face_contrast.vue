<template>
    <div class="rightNav">
        <!--        <ul class="tab-nav">-->
        <!--            <h3 style="padding:5px 0 5px 10px;border-bottom:1px solid #c2c2c2;">设备管理树</h3>-->
        <!--        </ul>-->
        <div class="test3">
            <div style="border-bottom:1px solid #c2c2c2;">
                <h3 style="padding:5px 0 5px 10px;">人脸库</h3>
            </div>
            <div style="margin:10px 0px 0px 10px;width: 98.5%;height: 100%">
                <div style="width:100%;height: 85%">
                    <DatePicker type="datetimerange" @on-change="dateChange" format="yyyy-MM-dd HH:mm"
                                placeholder="选择时间区段"
                                style="float:left;width: 300px"></DatePicker>
                        <p style="float: left;width: 80px;font-size: 16px; margin-top: 5px; margin-left: 25px">人员编号</p>
                        <Input v-model="peopleId" placeholder="请输入"
                               style="float:left;margin-right: 25px;width: 250px"/>
                        <p style="float: left;width: 80px;font-size: 16px; margin-top: 5px">人员姓名</p>
                        <Input v-model="peopleName" placeholder="请输入"
                               style="float:left;margin-right: 25px;width: 250px"/>
                        <Button type="primary" @click="getPeopleFaceInfo">查询</Button>
                    <Table :loading="loading" :columns="peopleInfoTableLabelList" :data="peopleInfoList"  @on-cell-click="onCellClick" style="margin-top: 20px" width="90%" height="650">
                        <template slot-scope="{ row }" slot="imgSlot">
                            <img :src="row.filePath" width="70px" height="70px"/>
                        </template>
                    </Table>
                </div>
                <div style="width: 98.5%;">
                    <Page :current="pageNum" :page-size="pageSize" :total="peopleInfoTotal"
                          @on-page-size-change="onPageSizeChange" @on-change="onPageNumChange" show-sizer
                          style="float: right;margin-right: 10px;font-size: 12px"/>

                    <Modal v-model="showBigPic" footer-hide width="80%" style="margin-top: -150px;">
                        <img :src="bigPicUrl" width="100%" style="object-fit: cover">
                    </Modal>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import http from "@/config/http";
    import config from "@/config/config";

    export default {
        name: "face_contrast",
        data() {
            return {
                peopleInfoList: [],
                peopleInfoTableLabelList: [
                    {
                        title: 'id',
                        key: 'id'
                    },
                    {
                        title: '人脸照片',
                        key: 'filePath',
                        slot: 'imgSlot'
                    },
                    {
                        title: '用户编号',
                        key: 'userId'
                    },
                    {
                        title: '用户姓名',
                        key: 'name'
                    },
                    {
                        title: '入库时间',
                        key: 'timestamp'
                    }

                ],
                peopleId: '',
                peopleName: '',
                sTime: 0,
                eTime: 0,
                pageSize: 10,
                pageNum: 1,
                peopleInfoTotal: 0,
                httpurl: config.axios.httpUrl,
                loading: true,
                showBigPic: false,
                bigPicUrl: ''
            }
        },
        methods: {
            getPeopleFaceInfo: function () {
                this.loading = true;
                let url = this.getPeopleInfoByPageUrl;
                let data = {
                    peopleId: this.peopleId,
                    peopleName: this.peopleName,
                    sTime: this.sTime,
                    eTime: this.eTime,
                    pageNum: this.pageNum,
                    pageSize: this.pageSize
                };
                this.$curl.post(url, data).then(res => {
                    if (res.code === 200) {
                        this.peopleInfoTotal = res.data.total;
                        for (let i in res.data.rows) {
                            res.data.rows[i].filePath = this.httpurl + res.data.rows[i].filePath;
                            res.data.rows[i].timestamp = this.format(
                                new Date(res.data.rows[i].timestamp <= 9999999999 ? (res.data.rows[i].timestamp * 1000) : res.data.rows[i].timestamp), "yyyy-MM-dd hh:mm:ss"
                            );
                        }
                        this.peopleInfoList = res.data.rows;
                        this.loading = false;
                    } else {
                        this.$Message.warning(res.msg);
                    }
                }, err => {
                    this.$Message.error(err);
                })

            },
            onPageSizeChange: function (data) {
                this.pageSize = data;
                this.getPeopleFaceInfo();
            },
            onPageNumChange: function (data) {
                this.pageNum = data;
                this.getPeopleFaceInfo();
            },
            onCellClick: function (row, column, data, event){
                if (column.key === 'filePath') {
                    this.bigPicUrl = data;
                    this.showBigPic = true;
                }
            },
            dateChange: function(date, type) {
                let sTimeDate = new Date(date[0]);
                let eTimeDate = new Date(date[1]);
                this.sTime = sTimeDate.getTime() / 1000;
                this.eTime = eTimeDate.getTime() / 1000;
            },
            format: function (date, fmt) {
                if (/(y+)/.test(fmt)) {
                    fmt = fmt.replace(
                        RegExp.$1,
                        (date.getFullYear() + "").substr(4 - RegExp.$1.length)
                    );
                }
                let o = {
                    "M+": date.getMonth() + 1,
                    "d+": date.getDate(),
                    "h+": date.getHours(),
                    "m+": date.getMinutes(),
                    "s+": date.getSeconds(),
                };
                for (let k in o) {
                    if (new RegExp(`(${k})`).test(fmt)) {
                        let str = o[k] + "";
                        fmt = fmt.replace(
                            RegExp.$1,
                            RegExp.$1.length === 1 ? str : padLeftZero(str)
                        );
                    }
                }

                function padLeftZero(str) {
                    return ("00" + str).substr(str.length);
                }
                return fmt;
            },
        },
        created() {
            this.getPeopleFaceInfo();
        },
        mixins: [http]
    }
</script>
