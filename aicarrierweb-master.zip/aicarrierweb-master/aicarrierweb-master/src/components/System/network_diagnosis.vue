<template>
    <div class="test3">
        <div class="title2">
            <h3>网络诊断</h3>
        </div>
        <div class="aline"></div>
        <div class="cont1">
            <div class="father">
                <label> 命令 </label>
                <Poptip trigger="hover" content="仅支持ping、ifconfig命令" placement="top">
                    <Input v-model="command" placeholder="请输入命令" style="margin-right: 50px;width: 220px"/>
                </Poptip>
                <Button type="primary" style="margin-left: 0px;" @click="runCommand">执行命令</Button>
                <br>
                <br>

                <Input element-id="textarea" v-model="value" readonly type="textarea" :rows="25" placeholder=""
                       style="width: 800px;"/>
            </div>
        </div>
    </div>

</template>

<script>
    import http from '@/config/http';
    import config from '@/config/config';

    export default {
        name: "network_diagnosis",
        data() {
            return {
                command: '',
                value: '',
                host: config.axios.baseURL,
                wsurl: config.axios.wsurl,
            }
        },
        methods: {
            runCommand: function () {
                let _this = this;
                let url = _this.runCommandUrl;
                let data = {
                    command: _this.command
                };
                _this.$curl.post(url, data).then(res => {
                    if (res.code === 200) {
                        _this.$Message.success(res.msg);
                    } else {
                        _this.$Message.warning(res.msg);
                    }
                }, err => {
                    _this.$Message.error(err);
                })

            },
            refresh: function () {
                var socket;
                var host = this.host;
                var _this = this;
                try {
                    socket = new WebSocket(this.wsurl);
                    socket.onopen = function (msg) {
                        console.log("socket session create sucess!");
                    };
                    socket.onmessage = function (msg) {
                        let datas = JSON.parse(msg.data.replaceAll('\'', '"'));
                        _this.value += datas['network'];
                        document.getElementById('textarea').scrollTop = document.getElementById('textarea').scrollHeight;
                    };
                    socket.onclose = function (msg) {
                        console.log("close Sucess");
                    };
                    socket.onerror = function (msg) {
                        console.log("Error!");
                    };
                } catch (ex) {
                    console.log(ex);
                }
            }
        },
        created: function () {
            var _this = this;
            _this.refresh();
        },
        mixins: [http]
    }
</script>

<style>

</style>
